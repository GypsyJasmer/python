#GLOBAL CONSTANTS
X='X'
O='O'
SPACE=' '


